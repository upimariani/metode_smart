<!-- Required Js -->
<!-- <script src="<?= base_url('asset/flat-able-lite/dist/') ?>assets/js/vendor-all.min.js"></script> -->
<script src="<?= base_url('asset/flat-able-lite/dist/') ?>assets/js/plugins/bootstrap.min.js"></script>
<script src="<?= base_url('asset/flat-able-lite/dist/') ?>assets/js/pcoded.min.js"></script>

<!-- Apex Chart -->
<script src="<?= base_url('asset/flat-able-lite/dist/') ?>assets/js/plugins/apexcharts.min.js"></script>


<!-- custom-chart js -->
<script src="<?= base_url('asset/flat-able-lite/dist/') ?>assets/js/pages/dashboard-main.js"></script>


</body>

</html>